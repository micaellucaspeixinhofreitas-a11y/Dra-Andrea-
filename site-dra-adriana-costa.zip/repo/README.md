# Dra. Adriana Costa · Odontologia Estética

Site institucional (página única, HTML + CSS + JS puro, sem build).

- WhatsApp: +55 13 99168-0720
- Endereço: Avenida Ana Costa, 493, Gonzaga, Santos – SP, 11060-003
- CROSP 121089

## Estrutura
```
index.html
assets/
  foto-dra-adriana.jpg
  logo-branca.png
  logo-azul.png
```

## Publicar na Vercel
1. Suba esta pasta para um repositório no GitHub.
2. Em vercel.com/new, importe o repositório.
3. Framework Preset: **Other**. Deixe Build Command e Output Directory vazios.
4. Clique em Deploy. Depois, adicione o domínio em Settings → Domains.
